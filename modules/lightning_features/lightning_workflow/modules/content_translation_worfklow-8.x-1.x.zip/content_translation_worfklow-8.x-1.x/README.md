# content_translation_worfklow

Let's assume you have enabled workbench_moderation + multilingual content.
Now you've some published content in multiple languages.

Without this module you are not able to create published versions in just one language, without unpublishing the others.
